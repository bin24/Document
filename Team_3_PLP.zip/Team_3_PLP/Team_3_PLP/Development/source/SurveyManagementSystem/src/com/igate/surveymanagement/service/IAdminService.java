package com.igate.surveymanagement.service;

public interface IAdminService {

}
