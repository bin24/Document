package com.igate.surveymanagement.bean;

import java.util.List;

import javax.validation.constraints.Pattern;

import org.springframework.stereotype.Component;
@Component
public class QuestionBean {
	private String quesId;
	
	@Pattern(regexp="^[a-zA-z!@#$%^&*()][a-zA-Z!@#$%^&*() ]{1,500}$", message="enter the valid Question")
	private String quesText;
	
	//@Pattern(regexp="^[1-4]$", message="select the question type")
	private String quesType;

	private List<OptionsBean> options;
	private List<AnswerBean> answers;
	public String getQuesId() {
		return quesId;
	}
	public void setQuesId(String quesId) {
		this.quesId = quesId;
	}
	public String getQuesText() {
		return quesText;
	}
	public void setQuesText(String quesText) {
		this.quesText = quesText;
	}
	public String getQuesType() {
		return quesType;
	}
	public void setQuesType(String quesType) {
		this.quesType = quesType;
	}
	
	public List<OptionsBean> getOptions() {
		return options;
	}
	public void setOptions(List<OptionsBean> options) {
		this.options = options;
	}
	public List<AnswerBean> getAnswers() {
		return answers;
	}
	public void setAnswers(List<AnswerBean> answers) {
		this.answers = answers;
	}
	public QuestionBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public QuestionBean(String quesText, String quesType, List<OptionsBean> options) {
		super();
		this.quesText = quesText;
		this.quesType = quesType;
		this.options = options;
	}
	@Override
	public String toString() {
		return "QuestionBean [quesId=" + quesId + ", quesText=" + quesText
				+ ", quesType=" + quesType + ", options=" + options
				+ ", answers=" + answers + "]";
	}

}
