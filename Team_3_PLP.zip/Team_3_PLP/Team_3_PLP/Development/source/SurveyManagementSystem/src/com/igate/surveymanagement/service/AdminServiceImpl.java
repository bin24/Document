package com.igate.surveymanagement.service;

public class AdminServiceImpl implements IAdminService {

}
