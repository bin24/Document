package com.igate.surveymanagement.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.igate.surveymanagement.bean.OptionsBean;
import com.igate.surveymanagement.bean.QuestionBean;
import com.igate.surveymanagement.bean.SurveyBean;
import com.igate.surveymanagement.bean.UserBean;
import com.igate.surveymanagement.service.ISurveyorService;

@Controller("/user")
public class SurveyorController {
	
	private ArrayList<String> questionType;
	private QuestionBean question;
	private SurveyBean surveyDetail;
	private OptionsBean option;
	private ArrayList<OptionsBean> optiondesc;
	private Integer questionTyp;
	private UserBean user;
	private ArrayList<QuestionBean> displayQuestion;
	
	
	String reviewHome="surveyReviewSurvey";
	String reviewSurvey="surveySurveyResult";
	String surveyEdit="surveyEditSurvey";
	
	@Autowired
	private ISurveyorService service;
	

	 

	

	/**
	 /************************************************************************************
	 * File         : SurveyorController.java 
	 * Package      : com.igate.surveymanagement.controller 
	 *  Version     : 1.0
	 *  Author      : Anoop Singh Jaswal(835985) 
	 *  Date        : Oct 17, 2015
	 *  Method Name : showReviewSurvey(Model model)
	 *  Return type : String
	 * Parameters   : Object of type Model 
	 * Description  : This method returns the name of the view that is to be displayed on the browser.
	 ************************************************************************************
	 */
	@RequestMapping(value="/showReviewSurvey")
	public String showReviewSurvey(Model model){
		try{
		List<SurveyBean> surveyList=service.getDistributedSurveyList();
		
		model.addAttribute("user",user );
		model.addAttribute("surveyList",surveyList);
		return reviewHome;
		}catch(DataAccessException e){
			String error="Error in Review Survey";
			model.addAttribute("error", error+e.getMessage());
			return "surveyErrorPage";
		}
		
	}


	/**
	 /************************************************************************************
	 * File         : SurveyorController.java 
	 * Package      : com.igate.surveymanagement.controller 
	 *  Version     : 1.0
	 *  Author      : Anoop Singh Jaswal(835985) 
	 *  Date        : Oct 17, 2015
	 *  Method Name : displayReviewSurvey(@RequestParam("surveyId") String surveyId,Model model)
	 *  Return type : String
	 * Parameters   : Object of type Model ,Parameter from Request Parameters
	 * Description  : This method returns the name of the view that is to be displayed on the browser.
	 ************************************************************************************
	 */
	
	@RequestMapping(value="/displayReview")
	public String displayReviewSurvey(@RequestParam("surveyId") String surveyId,Model model){
		try{
		List<QuestionBean> quesList=service.reviewSurvey(surveyId);
		
		model.addAttribute("user",user );
		model.addAttribute("quesList",quesList);
		return reviewSurvey;
		}catch(DataAccessException e){
		String error="Error while displaying review Survey";
		model.addAttribute("error", error+e.getMessage());
		return "surveyErrorPage";
	}
		
	}
	
	/**
	 /************************************************************************************
	 * File     : SurveyorController.java 
	 * Package  :com.igate.surveymanagement.controller 
	 *  Version : 1.0
	 *   Author : Balaji Veerappan 
	 *   Date   : Oct 20, 2015
	 ************************************************************************************
	 */

	@RequestMapping(value="/SurveyorHome") 
	public String surveyHome(@ModelAttribute("userObj") UserBean userObj,Model model){
		
	try{	
		List<UserBean> userList=service.validate(userObj);
		user=userList.get(0);
	
		surveyDetail=new SurveyBean();
		
		model.addAttribute("user",user );
		model.addAttribute("create",surveyDetail );
		return "surveyCreateSurvey";
		}catch(DataAccessException e){
		String error="Error while validating the user login";
		model.addAttribute("error", error+e.getMessage());
		return "surveyErrorPage";
	}
	}
	/**
	 /************************************************************************************
	 * File     : SurveyorController.java 
	 * Package  :com.igate.surveymanagement.controller 
	 *  Version : 1.0
	 *   Author : Balaji Veerappan 
	 *   Date   : Oct 20, 2015
	 ************************************************************************************
	 */
	
	@RequestMapping(value="/showSurveyorHome") 
	public String survey(Model model){
		
		
		
		surveyDetail=new SurveyBean();
		
		model.addAttribute("user",user );
		model.addAttribute("create",surveyDetail );
		return "surveyCreateSurvey";
	}
	/**
	 /************************************************************************************
	 * File     : SurveyorController.java 
	 * Package  :com.igate.surveymanagement.controller 
	 *  Version : 1.0
	 *   Author : Balaji Veerappan 
	 *   Date   : Oct 20, 2015
	 ************************************************************************************
	 */
	
	@RequestMapping(value="/create")
	public String addDetail(@ModelAttribute(value="create") @Valid SurveyBean survey,BindingResult result,Model model){
		try{
		model.addAttribute("user",user );
		if(result.hasErrors()){
			
			return "surveyCreateSurvey";
		}
	
		questionType=new ArrayList<String>();
		model.addAttribute("question",new QuestionBean());
		questionType.add("Single Choice Question");
		questionType.add("Multiple Choice Question");
		questionType.add("One line Answer");
		questionType.add("Descriptive Answer");
		model.addAttribute("questionType", questionType);
		
		surveyDetail.setSurveyTitle(survey.getSurveyTitle());
		surveyDetail.setSurveyDescription(survey.getSurveyDescription());
		model.addAttribute("addquestion", "op");
		boolean rs=service.createsurveyId(survey, user.getUserId());
		displayQuestion=new ArrayList<QuestionBean>();
		surveyDetail.setSurveyId(survey.getSurveyId());
		if(rs==true){
		model.addAttribute("survey",survey );
		
		return "surveyAddQuestion";
		}else{
			return "surveyErrorPage";
		}
	}catch(DataAccessException e){
		String error="Error while creating new survey";
		model.addAttribute("error", error+e.getMessage());
		return "surveyErrorPage";
	}
		
		
	}

		
	/**
	 /************************************************************************************
	 * File     : SurveyorController.java 
	 * Package  :com.igate.surveymanagement.controller 
	 *  Version : 1.0
	 *   Author : Balaji Veerappan 
	 *   Date   : Oct 20, 2015
	 ************************************************************************************
	 */
	
	
	@RequestMapping(value="/createsurveyquetsion")
	public String addquestion(@RequestParam("options") String[] options,@ModelAttribute(value="question") QuestionBean ques,BindingResult result,Model model){
		try{
		model.addAttribute("user",user );
		if(ques.getQuesText().equals("") || (ques.getQuesText()==null)){
			model.addAttribute("questionType", questionType);
			model.addAttribute("survey",surveyDetail );
			model.addAttribute("displayQuestion",displayQuestion);
			model.addAttribute("question", new QuestionBean());
			return "surveyAddQuestion";
		}
		
		ArrayList<OptionsBean> list=new ArrayList<OptionsBean>();
		
		
		
		for(String i:options){
			if(!(i.equals(""))){
			OptionsBean op=new OptionsBean();
			op.setOptionDesc(i);
			list.add(op);
			}
		}
		
		ques.setOptions(list);
		displayQuestion.add(ques);
		
		boolean i=service.createSurvey(surveyDetail, ques);
		
		if(i==true){
			model.addAttribute("questionType", questionType);
			model.addAttribute("survey",surveyDetail );
			model.addAttribute("displayQuestion",displayQuestion);
			model.addAttribute("question", new QuestionBean());
			return "surveyAddQuestion";
		}else{
			return "surveyErrorPage";
		}
	}catch(DataAccessException e){
		String error="Error while adding questions to new survey";
		model.addAttribute("error", error+e.getMessage());
		return "surveyErrorPage";
	}
				
	}
	/**************************************************************************************
	 * Method Name: showDistributionlist of surveys(Model model) Return type:List
	 * Parameters:Object of type Model Description:This method returns the name
	 * of the view that is to be displayed on the browser.
	 * 
	 * @author :PritikaSharma_835990
	 ***************************************************************************************/
	@RequestMapping(value="/showDistributeSurvey")
	public String checkLogin(Model model){
		try{
			model.addAttribute("user",user);
		model.addAttribute("surveyorBean", new SurveyBean());
		 List<SurveyBean>  surveyList = service.getSurveyDistributionList();
		 if (surveyList.isEmpty()) {
			
			String msg = "There are no records";
				model.addAttribute("msg", msg);
				return "surveyDistributionFail";
			}
		 
		 model.addAttribute("surveyList", surveyList);
		return "surveyDistributionViewList";
	
	}catch(DataAccessException e){
		String error="Error displaying the survey list for distribution";
		model.addAttribute("error", error+e.getMessage());
		return "surveyErrorPage";
	}
		 }


	/**************************************************************************************
	 * Method Name: showDistributionNumber of surveys(Model model) Return type:String
	 * Parameters:Object of type Model Description:This method returns the name
	 * of the view that is to be displayed on the browser.
	 * 
	 * @author :PritikaSharma_835990
	 ***************************************************************************************/
	
	@RequestMapping(value="/show")
	public String showDistributionNumber(Model model,@RequestParam(value="id")String surveyId){
		
	try{
		
		model.addAttribute("user",user);
		model.addAttribute("surveyId",surveyId);
	
		List<UserBean> distributionList=service.getDistributionNumber(surveyId);
			if(distributionList.isEmpty())
				return "surveyDistributionFail";
			else
				 model.addAttribute("distributionList",distributionList);
				
		return "surveyDistributionList";
	}catch(DataAccessException e){
		String error="Error while distributing the survey";
		model.addAttribute("error", error+e.getMessage());
		return "surveyErrorPage";
	}
	
		 }

	

	/**************************************************************************************
	 * Method Name: status of surveys of surveys(Model model) Return type:String
	 * Parameters:Object of type Model Description:This method returns the name
	 * of the view that is to be displayed on the browser.
	 * 
	 * @author :PritikaSharma_835990
	 ***************************************************************************************/
	@RequestMapping(value="/status")
	public String statusofsurveys(@RequestParam(value="userList") String[] userList,Model model,@RequestParam("expiryDays") String expiryDays,@RequestParam("surveyId") String surveyId ){
		int status=0;
		model.addAttribute("user",user);
	
		try{
			status=service.setDistributionStatus(userList,expiryDays,surveyId);

		if(status>0)
		return "surveyDistributionSetStatus";
			else
				
		return "surveyDistributionFail";
	}catch(DataAccessException e){
		String error="Error while updating the response status";
		model.addAttribute("error", error+e.getMessage());
		return "surveyErrorPage";
	}
	
		
		 }
	
	
	/**************************************************************************************
	 * Method Name: check responded survey of surveys(Model model) Return type:List
	 * Parameters:Object of type Model Description:This method returns the name
	 * of the view that is to be displayed on the browser.
	 * 
	 * @author :PritikaSharma_835990
	 ***************************************************************************************/
	
	
	@RequestMapping(value="/showrespondendsurveylist")
	public String checkrespondedsurvey(Model model){
		try{
		model.addAttribute("user",user);
		model.addAttribute("surveyorBean", new SurveyBean());
		 List<SurveyBean> respondedList = service.getRespondedSurveyList();
		 if (respondedList.isEmpty()) {
			
			String msg = "There are no records";
				model.addAttribute("msg", msg);
				return "myError";
			}
		 
		 model.addAttribute("respondedList", respondedList);
		return "respondedlist";
	}catch(DataAccessException e){
		String error="Error while checking the responded survey";
		model.addAttribute("error", error+e.getMessage());
		return "surveyErrorPage";
	}
	
		 }
	
	

	@RequestMapping("/showEditSurvey")
	public String getSurveyList(SurveyBean surveyBean, QuestionBean ques, Model model){
		model.addAttribute("user",user );
		try{
			List<SurveyBean> surveyList=service.getSurveyList();
		model.addAttribute("surveyList",surveyList);
		model.addAttribute("ques",ques.getQuesId());
		return "surveyEditSurvey";
	}catch(DataAccessException e){
		String error="Error while editing the survey";
		model.addAttribute("error", error+e.getMessage());
		return "surveyErrorPage";
	}
	}
	
	
	@RequestMapping("/showQuestionList")
	public String getSurveyQuestions(SurveyBean surveyBean,Model model, @RequestParam(value="surveyId") String surveyId,
			@RequestParam(value="quesId") String quesId){
		try{
		Integer.parseInt(surveyId);
		List<QuestionBean> quesList =new ArrayList<QuestionBean>();
		boolean result=service.checkDistributeSurvey(surveyId);
		if(result==true)
			
			return "surveyEditdistributed";
		model.addAttribute("user",user );
		quesList=service.getSurveyQuestions(surveyId);
		
		surveyBean=service.viewSurveyById(surveyId);
		model.addAttribute("surveyBean", surveyBean);
		model.addAttribute("quesList", quesList);
		
		return "surveyEditviewQuestions";
	}catch(DataAccessException e){
		String error="Error while displaying all survey";
		model.addAttribute("error", error+e.getMessage());
		return "surveyErrorPage";
	}
	}
	
	@RequestMapping("/editSurvey")
	public String editSurvey(@ModelAttribute("surveyBean")  SurveyBean surveyBean,Model model){
		try{
			model.addAttribute("user",user );
			model.addAttribute("surveyBean", surveyBean);
	
		boolean result=service.editSurveyDetails(surveyBean);
		
		
			
		return "surveyEditHome";
	}catch(DataAccessException e){
		String error="Error during edit survey";
		model.addAttribute("error", error+e.getMessage());
		return "surveyErrorPage";
	}
	}
	

	
	@RequestMapping("/deleteQuestion")
	public String editQuestions(QuestionBean questionBean,Model model,@RequestParam(value="quesId") String quesId){
		try{
			model.addAttribute("user",user );
			Integer.parseInt(quesId);
		questionBean.setQuesId(quesId);
		boolean result=service.deleteQuestions(quesId);
		
		
		return "surveyEditHome";
		}catch(DataAccessException e){
		String error="Error during delete survey question";
		model.addAttribute("error", error+e.getMessage());
		return "surveyErrorPage";
	}
	}
	
	@RequestMapping("/deleteSurvey")
	public String deleteSurvey(SurveyBean surveyBean,Model model,@RequestParam(value="surveyId") String surveyId){
		try{
			model.addAttribute("user",user );
			Integer.parseInt(surveyId);
		surveyBean.setSurveyId(surveyId);
	
		boolean result=service.deleteSurvey(surveyId);
	
		
		return "surveyEditHome";
	}catch(DataAccessException e){
		String error="Error while delete the edit survey";
		model.addAttribute("error", error+e.getMessage());
		return "surveyErrorPage";
	}
	}
	
	
	
	@RequestMapping(value="/createEdit")
	public String createEdit(@ModelAttribute(value="surveyBean") @Valid SurveyBean survey,BindingResult result,Model model){
		try{
		model.addAttribute("user",user );
		questionType=new ArrayList<String>();
		questionType=new ArrayList<String>();
		model.addAttribute("question",new QuestionBean());
		questionType.add("Single Choice Question");
		questionType.add("Multiple Choice Question");
		questionType.add("One line Answer");
		questionType.add("Descriptive Answer");
		model.addAttribute("questionType", questionType);
		displayQuestion=new ArrayList<QuestionBean>();
		
		surveyDetail.setSurveyTitle(survey.getSurveyTitle());
		surveyDetail.setSurveyDescription(survey.getSurveyDescription());
	
		
	
		surveyDetail.setSurveyId(survey.getSurveyId());
		
		model.addAttribute("survey",survey );
		
		return "surveyEditSurveyAddquestion";
		}catch(DataAccessException e){
		String error="Error while adding question to edit survey ";
		model.addAttribute("error", error+e.getMessage());
		return "surveyErrorPage";
	}
		}
		
	
	
	
	
	
	
	
	
	@RequestMapping(value="/createEditquestion")
	public String createEdit(@RequestParam("options") String[] options,@ModelAttribute(value="question") QuestionBean ques,BindingResult result,Model model){
		model.addAttribute("user",user );
		if(ques.getQuesText().equals("") || (ques.getQuesText()==null)){
			model.addAttribute("questionType", questionType);
			model.addAttribute("survey",surveyDetail );
			model.addAttribute("displayQuestion",displayQuestion);
			model.addAttribute("question", new QuestionBean());
			return "surveyAddQuestion";
		}
		
		ArrayList<OptionsBean> list=new ArrayList<OptionsBean>();
		
		
		
		for(String i:options){
			if(!(i.equals(""))){
			OptionsBean op=new OptionsBean();
			op.setOptionDesc(i);
			list.add(op);
			}
		}
		
		ques.setOptions(list);
		displayQuestion.add(ques);
		
		boolean i=service.createSurvey(surveyDetail, ques);
		
		if(i==true){
			model.addAttribute("questionType", questionType);
			model.addAttribute("survey",surveyDetail );
			model.addAttribute("displayQuestion",displayQuestion);
			model.addAttribute("question", new QuestionBean());
			return "surveyEditSurveyAddquestion";
		}else{
			return "surveyErrorPage";
		}
}
}

	
	
	
