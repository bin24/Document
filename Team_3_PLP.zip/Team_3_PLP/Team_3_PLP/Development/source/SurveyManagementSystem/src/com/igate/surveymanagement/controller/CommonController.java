package com.igate.surveymanagement.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.igate.surveymanagement.bean.UserBean;
import com.igate.surveymanagement.service.CommonServiceImpl;


@Scope("session")
@Controller
public class CommonController {
	
	private final String SURVEY_LOGIN_PAGE="surveyLoginPage";
	private final String SURVEY_ERROR_PAGE="surveyErrorPage";
	private final String SURVEY_DASHBOARD_PAGE="surveyDashboardPage";
	private final String SURVEY_ADMIN_PAGE="surveyAdminPage";
	private final String SURVEY_ADDUSER_PAGE="surveyAddUserPage";
	private final String SURVEY_USERSLIST_PAGE="surveyUserList";
	
	List<UserBean> userList;
	
	@Autowired
	UserBean user;

	@Autowired
	CommonServiceImpl service;
	
	@RequestMapping(value="/showLogin")	
	public String prepareLogin(Model model)
	{
		
		model.addAttribute("user",new UserBean());
		return SURVEY_LOGIN_PAGE;
	}
	
	
	
	@RequestMapping(value="/checkLogin")	
	public String checkLogin(@ModelAttribute(value="user") @Valid UserBean user,BindingResult result,Model model,HttpSession session)
	{
		try{
			
		
		if(result.getFieldError("userId") != null ||result.getFieldError("userPassword") != null )
		{
			return SURVEY_LOGIN_PAGE;
		}
		
		
		List<UserBean> user1=new ArrayList<UserBean>();
		user1=service.validate(user);
		
		if(user1.isEmpty()){
			model.addAttribute("user",new UserBean());
			model.addAttribute("invalid",true);
			return SURVEY_LOGIN_PAGE;
		}			
		else{
			user=user1.get(0);			
		
			model.addAttribute("userObj",user1.get(0));
			model.addAttribute("user",user1.get(0));
			
			if(user.getUserType().equalsIgnoreCase("ad")){
				
				userList=service.getAllUserList();
				
				model.addAttribute("userList",userList);
				model.addAttribute("newUser",new UserBean());
				return SURVEY_ADMIN_PAGE;
				}
			else if(user.getUserType().equalsIgnoreCase("sy")){
				model.addAttribute("userObj",user1.get(0));
				return "forward:/SurveyorHome.obj";
				}
			else{
				
				session.setAttribute("userObj", user1.get(0));
				return "forward:/showResponderHome.obj";
			}
		}
	}catch(DataAccessException e){
		String error="Error during validation the user authentication";
		model.addAttribute("error", error+e.getMessage());
		model.addAttribute("direct",SURVEY_LOGIN_PAGE);
		return "surveyErrorPage";
	}
		
			
		
	}
	@RequestMapping(value="/showAddUser")	
	public String showAddUser(Model model){
		model.addAttribute("newUser",new UserBean());
		return SURVEY_ADDUSER_PAGE;
		
	}
	
	@RequestMapping(value="/createUser")	
	public  String checkAddUser(@ModelAttribute(value="newUser") @Valid UserBean newuser,BindingResult result,Model model)
	{
		try{
			if(result.hasFieldErrors("userPassword") ||result.hasFieldErrors("firstName") ||result.hasFieldErrors("lastName") ||result.hasFieldErrors("userType")  )
		
		{	
			return SURVEY_ADDUSER_PAGE;
		}
			else{
		
		
					int rowcount=service.newUser(newuser);
					
					
					if(rowcount==0)
					{
						
						model.addAttribute("userAdded",false);
						return SURVEY_ADDUSER_PAGE;
					}
					
					else
					{	model.addAttribute("userAdded",true);
						model.addAttribute("userId",rowcount);
						return SURVEY_ADDUSER_PAGE;
					}
			}
	}catch(DataAccessException e){
		String error="Error during validation the user authentication";
		model.addAttribute("error", error+e.getMessage());
		return "surveyErrorPage";
	}
		
	}
	@RequestMapping(value="/showAllUsers")	
	public String showAllUsersList(Model model){
	try{	
		userList=service.getAllUserList();
		model.addAttribute("userList",userList);
		return SURVEY_USERSLIST_PAGE;
	}catch(DataAccessException e){
		String error="Error displaying all the user";
		model.addAttribute("error", error+e.getMessage());
		return "surveyErrorPage";
	}
		
	}
	@RequestMapping(value="/showEditUsers")	
	public String showEditUser(Model model,@RequestParam("userId") String userId){
		try{
			UserBean user=service.getUserDetails(userId);
		model.addAttribute("newUser",user);
		return SURVEY_ADDUSER_PAGE;
	}catch(DataAccessException e){
		String error="Error in editing the user details";
		model.addAttribute("error", error+e.getMessage());
		return "surveyErrorPage";
	}
		
	}
	 @RequestMapping(value="/logout")
	  public String logout(HttpSession session,Model model) {
	    try{session.invalidate();
	  
	    model.addAttribute("user",new UserBean());
	    return SURVEY_LOGIN_PAGE;
		}catch(DataAccessException e){
			String error="Error during logout";
			model.addAttribute("error", error+e.getMessage());
			return "surveyErrorPage";
		}
	  }
	 
	 @RequestMapping(value="/updateUserDetails")
	 public String updateUserDetails(@ModelAttribute("newUser") @Valid UserBean user,BindingResult result,Model model ){
		try{
			if(result.hasErrors())
			{	
				return SURVEY_ADDUSER_PAGE;
			}
		 else{
			boolean res= service.updateUserDetails(user);
			
		
				if(res){
					model.addAttribute("updateMsg","User Details Updated Successfully");
				}else{
					model.addAttribute("updateMsg","Cannot Updated User Details");
				}
							
			
			return SURVEY_ADDUSER_PAGE;
		 }
		 
		}catch(DataAccessException e){
			String error="Error during updating the user details";
			model.addAttribute("error", error+e.getMessage());
			return "surveyErrorPage";
		}
	 }
	
}
