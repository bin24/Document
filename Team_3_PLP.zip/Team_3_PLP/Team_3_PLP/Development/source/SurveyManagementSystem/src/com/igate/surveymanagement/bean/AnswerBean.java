package com.igate.surveymanagement.bean;

import java.util.List;

import org.springframework.stereotype.Component;
@Component
public class AnswerBean {
	private String answer;
	private String userName;
	private String userId;
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
}
