package com.igate.surveymanagement.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.igate.surveymanagement.bean.QuestionBean;
import com.igate.surveymanagement.bean.SurveyBean;
import com.igate.surveymanagement.bean.UserBean;
import com.igate.surveymanagement.dao.ISurveyorDAO;

@Service
public class SurveyorServiceImpl implements ISurveyorService {
	@Autowired
	ISurveyorDAO  dao;

	@Override
	public List<QuestionBean> reviewSurvey(String surveyId) {
		
		return dao.reviewSurvey(surveyId);
	}

	@Override
	public boolean createsurveyId(SurveyBean survey, String userId) {
		// TODO Auto-generated method stub
		
		return dao.createsurveyId(survey, userId);
	}

	@Override
	public boolean createSurvey(SurveyBean survey, QuestionBean question) {
		// TODO Auto-generated method stub
		return dao.createSurvey(survey, question);
	}

	@Override
	public List<UserBean> validate(UserBean login) {
		
		return dao.validate(login);
	}

	@Override
	public List<SurveyBean> getDistributedSurveyList() {
		
		return dao.getDistributedSurveyList();
	}

	@Override
	public List<SurveyBean> getSurveyDistributionList() {
	
		return dao.getSurveyDistributionList();
	}

	@Override
	public List<UserBean> getDistributionNumber(String surveyId) {
	
		return dao.getDistributionNumber(surveyId);
	}

	@Override
	public int setDistributionStatus(String[] userList,String expiryDays,String surveyId) {
		
		return dao.setDistributionStatus(userList,expiryDays,surveyId);
	}

	@Override
	public List<SurveyBean> getRespondedSurveyList() {
		
		return dao.getRespondedSurveyList();
	}
	@Override
	public List<SurveyBean> getSurveyList() {
		// TODO Auto-generated method stub
		return dao.getSurveyList();
	}


	
	
	
	@Override
	public List<QuestionBean> getSurveyQuestions(String surveyId) {
		// TODO Auto-generated method stub
		return dao.getSurveyQuestions(surveyId);
	}

	@Override
	public boolean editSurveyDetails(SurveyBean surveyBean) {
		// TODO Auto-generated method stub
		return dao.editSurveyDetails(surveyBean);
	}

	@Override
	public boolean deleteQuestions(String quesId) {
		// TODO Auto-generated method stub
		return dao.deleteQuestions(quesId);
	}

	@Override
	public SurveyBean viewSurveyById(String SurveyId) {
		// TODO Auto-generated method stub
		return dao.viewSurveyById(SurveyId);
	}

	@Override
	public boolean editSurveyQuestions(List<QuestionBean> quesList) {
		// TODO Auto-generated method stub
		return dao.editSurveyQuestions(quesList);
	}

	@Override
	public boolean deleteSurvey(String surveyId) {
		// TODO Auto-generated method stub
		return dao.deleteSurvey(surveyId);
	}

	@Override
	public boolean checkDistributeSurvey(String surveyId) {
		// TODO Auto-generated method stub
		return dao.checkDistributeSurvey(surveyId);
	}

}

	


