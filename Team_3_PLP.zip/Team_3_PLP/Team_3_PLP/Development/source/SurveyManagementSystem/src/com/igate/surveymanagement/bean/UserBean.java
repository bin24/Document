package com.igate.surveymanagement.bean;

import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.stereotype.Component;

@Component
public class UserBean {
	@Override
	public String toString() {
		return "UserBean [userId=" + userId + ", userPassword=" + userPassword
				+ ", firstName=" + firstName + ", lastName=" + lastName
				+ ", userType=" + userType + ", activeUser=" + activeUser + "]";
	}
	private String userId;
	private String userPassword;
	private String firstName;
	private String lastName;
	private String userType;
	private String activeUser;
	
	public String getActiveUser() {
		return activeUser;
	}
	public void setActiveUser(String activeUser) {
		this.activeUser = activeUser;
	}
	@Pattern (regexp = "^[0-9]{6}$", message = "Invalid User Id")
	public String getUserId() {
		return userId;
	}
	
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	@NotEmpty(message="Field Cannot be Empty")
	public String getUserPassword() {
		return userPassword;
	}
	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}
	
	@NotEmpty(message="Required")
	@Pattern (regexp = "^[A-Za-z]+$", message = "Only alphabets allowed ")
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	
	@NotEmpty(message="Required")
	@Pattern (regexp = "^[A-Za-z]+$", message = "Only alphabets allowed ")
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	@NotEmpty(message="Required")
	public String getUserType() {
		return userType;
	}
	public void setUserType(String userType) {
		this.userType = userType;
	}
	public UserBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

}
