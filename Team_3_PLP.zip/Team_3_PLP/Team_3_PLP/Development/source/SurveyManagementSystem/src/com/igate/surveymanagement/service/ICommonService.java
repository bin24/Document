package com.igate.surveymanagement.service;

import java.util.List;

import com.igate.surveymanagement.bean.UserBean;

public interface ICommonService {
	public List<UserBean> validate(UserBean login);
	public int newUser(UserBean newuser);
	public List<UserBean> getAllUserList();
	public UserBean getUserDetails(String userId);
	public Boolean  updateUserDetails(UserBean user);
	public UserBean setUserStatus(String status);
}
