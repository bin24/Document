package com.igate.surveymanagement.dao;

import java.util.ArrayList;
import java.util.List;




import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.igate.surveymanagement.bean.AnswerBean;
import com.igate.surveymanagement.bean.OptionsBean;
import com.igate.surveymanagement.bean.QuestionBean;
import com.igate.surveymanagement.bean.SurveyBean;



@Repository("dao")
public class ResponderDAOImpl implements IResponderDAO {
	
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	@Autowired
	private QuestionRowMapper quesMapper;
	
	@Autowired
	private OptionRowMapper optMapper;
	
	@Autowired
	private SurveyRowMapper surveyMapper;
	
	public List<SurveyBean> getSurveyList(String responderId){
	
		List<SurveyBean> responderSurveyList= new ArrayList<SurveyBean>();
		String sql="SELECT  m.survey_id, m.survey_title, m.survey_description "
				+ "FROM survey_master m WHERE m.survey_id "
				+ "IN( SELECT sd.survey_id "
				+ "FROM SURVEY_RESPONDENT_RELATIONSHIP srr,SURVEY_DISTRIBUTION sd "
				+ "WHERE sd.DISTRIBUTION_ID=srr.DISTRIBUTION_ID  AND srr.RESPONSE_STATUS=0"
				+ "AND srr.user_id=?)";
		Object[] params= new Object[]{responderId};
		
		responderSurveyList= jdbcTemplate.query(sql, params, surveyMapper);
		
		return responderSurveyList;
	}
	

	@Override
	public List<QuestionBean> getSurveyDetails(String surveyId) {
		// TODO Auto-generated method stub
		List<QuestionBean> responderQuestionDetails= new ArrayList<QuestionBean>();
	
		//Code to get Questions from the Database
		List<QuestionBean> responderQuestionList=new ArrayList<QuestionBean>();
		String sql="SELECT question_id,question_type,question_text FROM survey_question_details WHERE survey_id=?";
		Object[] params=new Object[]{surveyId};
		
		responderQuestionList= jdbcTemplate.query(sql, params,quesMapper);
		
		for(QuestionBean ques:responderQuestionList){
			
				List<OptionsBean> optList= new ArrayList<OptionsBean>();
				String sql1="SELECT option_id,(select 0 from dual)AS Count,option_description FROM survey_question_options WHERE question_id=?";
				Object[] params1=new Object[]{ques.getQuesId()};
				
				optList=jdbcTemplate.query(sql1, params1, optMapper);
				ques.setOptions(optList);
				responderQuestionDetails.add(ques);
				
		}
		System.out.println(responderQuestionDetails);
		return responderQuestionDetails;
		
	}


	@Override
	public int respondSurvey(String surveyId,String userId,List<QuestionBean> quesList) {
		
		int rowcount=1; 
		int distributionId=0;
		
		
		String sql="SELECT sd.DISTRIBUTION_ID FROM SURVEY_RESPONDENT_RELATIONSHIP srr,SURVEY_DISTRIBUTION sd WHERE sd.survey_id=? AND srr.user_id=? AND sd.DISTRIBUTION_ID=srr.DISTRIBUTION_ID";
		String sql1="INSERT INTO SURVEY_RESPONDENT_ANSWERS VALUES(?,?,?,?,null)";
		String sql2="INSERT INTO SURVEY_RESPONDENT_ANSWERS VALUES(?,?,?,null,?)";
		String sql3="UPDATE SURVEY_RESPONDENT_RELATIONSHIP SET response_status=1 where user_id=? AND distribution_id=?";
		
		Object[] param=new Object[]{surveyId,userId};
		distributionId=jdbcTemplate.queryForObject(sql, param,Integer.class);
		
		for(QuestionBean ques:quesList){
			
			if(ques.getQuesType().equalsIgnoreCase("1") || ques.getQuesType().equalsIgnoreCase("2")){
				
				for(OptionsBean opt:ques.getOptions()){
					Object[] param1=new Object[]{Integer.parseInt(userId),distributionId,Integer.parseInt(ques.getQuesId()),Integer.parseInt(opt.getOptionDesc())};
					
					int count=jdbcTemplate.update(sql1, param1);
					rowcount*=count;
					
				}
			}
			if(ques.getQuesType().equalsIgnoreCase("3") || ques.getQuesType().equalsIgnoreCase("4"))
			{
				
				AnswerBean ans=ques.getAnswers().get(0);
				Object[] param1=new Object[]{Integer.parseInt(userId),distributionId,Integer.parseInt(ques.getQuesId()),ans.getAnswer()};
				int count=jdbcTemplate.update(sql2, param1);
				rowcount*=count;
				
			}
			
		}
		if(rowcount==1){
			Object[] param1=new Object[]{Integer.parseInt(userId),distributionId};
			rowcount=jdbcTemplate.update(sql3, param1);
		}
		
		
		return rowcount;
	}

	

}
