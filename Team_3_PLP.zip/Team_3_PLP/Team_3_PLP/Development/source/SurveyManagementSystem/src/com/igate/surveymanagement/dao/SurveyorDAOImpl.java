package com.igate.surveymanagement.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;




import org.springframework.stereotype.Repository;

import com.igate.surveymanagement.bean.AnswerBean;
import com.igate.surveymanagement.bean.OptionsBean;
import com.igate.surveymanagement.bean.QuestionBean;
import com.igate.surveymanagement.bean.SurveyBean;
import com.igate.surveymanagement.bean.UserBean;

@Repository
public class SurveyorDAOImpl implements ISurveyorDAO  {

	String questionSingleChoice="1";
	String questionMupltipleChoice="2";

	@Autowired
	CommonRowMapper commonMapper;
	
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	@Autowired
	private QuestionRowMapper quesMapper;
	
	@Autowired
	private OptionRowMapper optMapper;
	
	@Autowired
	private AnswerRowMapper ansMapper;
	@Autowired
	private SurveyRowMapper surveyMapper;
	
	
	


	@Override
	public List<QuestionBean> reviewSurvey(String surveyId) {
		
		String sql = "SELECT QUESTION_ID,QUESTION_TYPE,QUESTION_TEXT "
				+ "FROM SURVEY_QUESTION_DETAILS "
				+ "WHERE SURVEY_ID=?";
		
		String sql1="SELECT sqo.OPTION_ID,"
				+ "(SELECT COUNT(sra.OPTION_ID) "
				+ "FROM SURVEY_RESPONDENT_ANSWERS sra "
				+ "WHERE sra.OPTION_ID=sqo.OPTION_ID) AS COUNT,"
				+ "sqo.OPTION_DESCRIPTION "
				+ "FROM SURVEY_QUESTION_OPTIONS sqo "
				+ "WHERE QUESTION_ID=?";
		String sql2="SELECT um.FIRST_NAME ||' '|| um.LAST_NAME as name,um.USER_ID,sqa.ANSWER_TEXT "
				+ "FROM SURVEY_RESPONDENT_ANSWERS sqa,USER_MASTER um " 
				+ "WHERE sqa.USER_ID=um.USER_ID AND QUESTION_ID=?";
		
		Object[] params=new Object[]{surveyId};
		List<QuestionBean> quesList=(List<QuestionBean>) jdbcTemplate.query(sql,params, quesMapper);
		
		System.out.println(quesList);
		for(QuestionBean ques:quesList)
		{
			Object[] params1=new Object[]{ques.getQuesId()};
			if(ques.getQuesType().equals(questionSingleChoice) ||ques.getQuesType().equals(questionMupltipleChoice) )
			{
				
				List<OptionsBean> optionList=(List<OptionsBean>) jdbcTemplate.query(sql1,params1, optMapper);
				ques.setOptions(optionList);
			}	
			else{
				
				List<AnswerBean> ansList=(List<AnswerBean>) jdbcTemplate.query(sql2,params1, ansMapper);
				ques.setAnswers(ansList);
			}		
			
		}
		
		return quesList;
	}

	@Override
	public List<QuestionBean> reviewSurvey() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean createsurveyId(SurveyBean survey,String userId) {
		// TODO Auto-generated method stub
		
		String query="SELECT SURVEY_ID_SEQ.NEXTVAL FROM DUAL";
		String query1="INSERT INTO SURVEY_MASTER VALUES(?,?,?,?)";
		
		Integer id=jdbcTemplate.queryForObject(query,Integer.class);
		survey.setSurveyId((id.toString()));
		System.out.println(survey.getSurveyId());
		Object[] param=new Object[]{survey.getSurveyId(),survey.getSurveyTitle(),survey.getSurveyDescription(),userId};
		int result=jdbcTemplate.update(query1,param);
		
		if((result)>0){
			
			
				return true;
		}else{
		
		return false;
	}
}

	@Override
	public boolean createSurvey(SurveyBean survey, QuestionBean question) {
		// TODO Auto-generated method stub
		String query="INSERT INTO SURVEY_QUESTION_DETAILS VALUES(?,?,?,?)";
		String query2="SELECT SURVEY_QUES_SEQ.NEXTVAL FROM DUAL";
		String query1="INSERT INTO SURVEY_QUESTION_OPTIONS VALUES(SURVEY_QUESOPT_SEQ.NEXTVAL,?,?)";
		System.out.println("*****************");
		int questiontype=Integer.parseInt(question.getQuesType());
		System.out.println(questiontype);
		Integer id=jdbcTemplate.queryForObject(query2,Integer.class);
		Object[] param=new Object[]{id,survey.getSurveyId(),question.getQuesText(),question.getQuesType()};
		int success=jdbcTemplate.update(query,param);
		
		int optionUpdate = 0;
		boolean result;
		System.out.println(id);
		if(success>0){
			System.out.println("*****************in");
			if(questiontype>0 || questiontype <=2)
				for (OptionsBean option : question.getOptions()) {
					System.out.println(option.getOptionDesc());
					Object[] param1=new Object[]{id,option.getOptionDesc()};
					optionUpdate=jdbcTemplate.update(query1,param1);
				}
			else
				System.out.println("****************else");
				result=true;
				return result;
				
		
		}
		System.out.println(optionUpdate);
		if(optionUpdate>0)
			result=true;
		else
			result=false;
		return result;
	}
	
	
	
	@Override
	public List<UserBean> validate(UserBean user) {
		// TODO Auto-generated method stub
		
		System.out.println("in dao ");
		List<UserBean> user1=new ArrayList<UserBean>();
		
		String status="y"; 
		String query="SELECT USER_ID,FIRST_NAME,LAST_NAME,USER_TYPE,USER_ACTIVE,USER_PASSWORD FROM user_master WHERE USER_ID=? AND USER_PASSWORD=? AND USER_ACTIVE='y'";
		Object[] params=new Object[]{user.getUserId(),user.getUserPassword()};
		
	
		user1= jdbcTemplate.query(query, params,commonMapper);
		
		return  user1;
	}

	@Override
	public List<SurveyBean> getDistributedSurveyList() {
		List<SurveyBean> surveyList=new ArrayList<SurveyBean>();
	String sql="SELECT * FROM Survey_Master where survey_id IN (SELECT DISTINCT survey_id from survey_distribution)";
	surveyList= jdbcTemplate.query(sql,surveyMapper);	
	
	return surveyList;
	}
	/**************************************************************************************
	 * Method Name: getSurveyDistributionList of surveys(Model model) Return type:List
	 * Parameters:Object of type Model Description:This method returns the name
	 * of the view that is to be displayed on the browser.
	 * 
	 * @author :PritikaSharma_835990
	 ***************************************************************************************/
	
	@Override
	public List<SurveyBean> getSurveyDistributionList() {
		// TODO Auto-generated method stub
		String sql="SELECT sm.SURVEY_ID,sm.SURVEY_TITLE,sm.SURVEY_DESCRIPTION"
				
		+"	  FROM SURVEY_MASTER sm WHERE  sm.SURVEY_ID IN(SELECT DISTINCT SURVEY_ID FROM SURVEY_QUESTION_DETAILS)";
		  List<SurveyBean> list=jdbcTemplate.query(sql,surveyMapper);
		  for(SurveyBean c:list){
			  System.out.println("in list");
			  System.out.println(c);
		  }
	return list;
	
	}

	/**************************************************************************************
	 * Method Name: getdistributionNumber of surveys(Model model) Return type:List
	 * Parameters:Object of type Model Description:This method returns the name
	 * of the view that is to be displayed on the browser.
	 * 
	 * @author :PritikaSharma_835990
	 ***************************************************************************************/
	

	@Override
 public  List<UserBean> getDistributionNumber(String surveyId) {
		System.out.println("surveyId="+surveyId);
		// TODO Auto-generated method stub
		String sql="select USER_ID,FIRST_NAME,LAST_NAME,USER_TYPE,USER_ACTIVE,USER_PASSWORD from user_master where user_id NOT IN(select r.user_id from SURVEY_RESPONDENT_RELATIONSHIP r,USER_MASTER m "+
                   " where r.DISTRIBUTION_ID IN(select distribution_id from SURVEY_DISTRIBUTION where SURVEY_ID=?) and m.user_type='rs'"+
                      "and m.user_id=r.user_id) and user_type='rs'";
		Object[] params=new Object[]{surveyId};
		 List<UserBean> list=jdbcTemplate.query(sql,params,commonMapper);
		return  list;
		
	

}
	 public  int setDistributionStatus(String[] userList,String expiryDays,String surveyId) {
			int res=0;
			int sequence;
			String sql_sequence="select SURVEY_DISTRIBUTION_SEQ.NEXTVAL from dual";
			String sql="insert into survey_distribution p values(?,?,SYSDATE,SYSDATE+?)";
			String sql1="insert into survey_respondent_relationship  values(?,?,0)";
			
			sequence=jdbcTemplate.queryForObject(sql_sequence,Integer.class);
			if(sequence!=0){
				Object[] params=new Object[]{sequence,surveyId,Integer.parseInt(expiryDays)};
				int status=jdbcTemplate.update(sql,params);
				
			for(String userId:userList){					
					
					if(status>0){
						Object[] params1=new Object[]{sequence,userId};
						res+=jdbcTemplate.update(sql1,params1);
					}
				}
			}
			if(res==userList.length){
				return 1;
			}
			else{
				return 0;
			}
		
			
}
		/**************************************************************************************
		 * Method Name: get responded survey list of surveys(Model model) Return type:List
		 * Parameters:Object of type Model Description:This method returns the name
		 * of the view that is to be displayed on the browser.
		 * 
		 * @author :PritikaSharma_835990
		 ***************************************************************************************/
	 @Override
		public List<SurveyBean> getRespondedSurveyList() {
			// TODO Auto-generated method stub
			String sql="SELECT sm.SURVEY_ID,sm.SURVEY_TITLE,sm.SURVEY_DESCRIPTION   FROM SURVEY_MASTER sm WHERE sm.USER_ID in(select user_id from SURVEY_RESPONDENT_RELATIONSHIP where response_status=1)";
			  List<SurveyBean> rlist=jdbcTemplate.query(sql,surveyMapper);
			  for(SurveyBean c:rlist){
				  System.out.println("in list");
				  System.out.println(c);
			  }
		return rlist;
}
	
	 
	 @Override
		@SuppressWarnings("unchecked")
		public List<SurveyBean> getSurveyList() {
			// TODO Auto-generated method stub
			String query="SELECT survey_title,survey_Description,survey_id FROM survey_master";
			List<SurveyBean> surveyList=jdbcTemplate.query(query,new SurveyorRowMapper());
			return surveyList;
		}
	 
	 
	 
	 @Override
		public SurveyBean viewSurveyById(String SurveyId) {
			// TODO Auto-generated method stub
			String query="SELECT survey_title, survey_description,survey_id FROM survey_master WHERE survey_id=?";
			SurveyBean surveyBean=jdbcTemplate.queryForObject(query, new SurveyorRowMapper(),SurveyId);
			return surveyBean;
		}
		

		@Override
		public boolean editSurveyDetails(SurveyBean surveyBean) {
			// TODO Auto-generated method stub
			boolean result=false;
			int id= Integer.parseInt(surveyBean.getSurveyId());
			String query="UPDATE survey_master SET survey_title=?,survey_description=? WHERE survey_id=?";
			System.out.println(surveyBean.getSurveyTitle());
			Object[] params=new Object[]{surveyBean.getSurveyTitle(),surveyBean.getSurveyDescription(),id};
			int rowCount=jdbcTemplate.update(query,params);
			
			if(rowCount>0)
				result= true;
			else
				result= false;
		
		return result;
			
		}
		



		@Override
		public List<QuestionBean> getSurveyQuestions(String surveyId) {
			// TODO Auto-generated method stub
			List<QuestionBean> quesList= new ArrayList<QuestionBean>();
			List<OptionsBean> optList= new ArrayList<OptionsBean>();
			
			String quesType="select question_type,question_text,question_id from survey_question_details WHERE survey_id=?";
			quesList=jdbcTemplate.query(quesType, new QuestionsRowMapper(),surveyId);
			
			for(QuestionBean bean:quesList){		
				if(bean.getQuesType().equals("1") || (bean.getQuesType()).equals("2")){
				String optQuery="SELECT option_description FROM survey_question_options WHERE question_id=?";
				optList=jdbcTemplate.query(optQuery, new OptionsRowMapper(),bean.getQuesId());
				bean.setOptions(optList);
				}
			}System.out.println(quesList);
			return quesList;
		}
		

		@Override
		public boolean editSurveyQuestions(List<QuestionBean> quesList) {
			// TODO Auto-generated method stub
			boolean result=false;
			int rowCount = 0;
			for(QuestionBean questionBean:quesList){
				int id= Integer.parseInt(questionBean.getQuesId());
				String query="UPDATE survey_question_details SET question_text=?,question_type=? WHERE question_id=?";
				System.out.println(questionBean.getQuesText());
				Object[] params=new Object[]{questionBean.getQuesText(),questionBean.getQuesType(),id};
				 rowCount=jdbcTemplate.update(query,params);
			}
			
			if(rowCount>0)
				result= true;
			else
				result= false;
			return result;
		}
		
		@Override
		public boolean deleteQuestions(String quesId) {
			// TODO Auto-generated method stub
			boolean result=false;

			String query="DELETE FROM survey_question_options WHERE question_id=?";
			int rowCount=jdbcTemplate.update(query,quesId);
				if(rowCount>0)
					result= true;
				else
					result= false;
				
			String query1="DELETE FROM survey_question_details WHERE question_id=?";
			 rowCount=jdbcTemplate.update(query1,quesId);
				if(rowCount>0)
					result= true;
				else
					result= false;
			
			return result;
		}
		

		@Override
		public boolean deleteSurvey(String surveyId) {
			// TODO Auto-generated method stub
			boolean result=false;
			System.out.println(surveyId+"dao");
			String query="DELETE FROM survey_question_details WHERE survey_id=?";
			int rowCount=jdbcTemplate.update(query,surveyId);
			if(rowCount>0)
				result= true;
			else
				result= false;
			System.out.println("dao q"+result);
			
			String query2="DELETE FROM survey_distribution WHERE survey_id=?";
			rowCount=jdbcTemplate.update(query2, surveyId);
			if(rowCount>0)
				result= true;
			else
				result= false;
			
			String query1="DELETE FROM survey_master WHERE survey_id=?";
			 rowCount=jdbcTemplate.update(query1,surveyId);
				if(rowCount>0)
					result= true;
				else
					result= false;
				System.out.println("dao s"+result);
			return result;
				
			}

		@Override
		public List<UserBean> getResponderList(String surveyId) {
			// TODO Auto-generated method stub
			return null;
		}


		@Override
		public boolean checkDistributeSurvey(String surveyId) {
			boolean result=false;
			String queryd="SELECT survey_id FROM survey_distribution WHERE survey_id=?";
			Object[] params=new Object[]{surveyId};
			List<Integer> id=jdbcTemplate.queryForList(queryd, params, Integer.class);
			for(Integer sid:id)
				if(sid==Integer.parseInt(surveyId))
				 result=true;
			else
				result=false;
			return result;
		}

	


	 
	 

}
