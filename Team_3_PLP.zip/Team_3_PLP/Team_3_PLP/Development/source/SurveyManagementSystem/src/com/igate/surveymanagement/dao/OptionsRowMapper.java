package com.igate.surveymanagement.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.igate.surveymanagement.bean.OptionsBean;

public class OptionsRowMapper implements RowMapper {

	@Override
	public Object mapRow(ResultSet resultSet, int arg1) throws SQLException {
		// TODO Auto-generated method stub
		OptionsBean optionsBean=new OptionsBean();
		optionsBean.setOptionDesc(resultSet.getString(1));
		return optionsBean;
	}

}
