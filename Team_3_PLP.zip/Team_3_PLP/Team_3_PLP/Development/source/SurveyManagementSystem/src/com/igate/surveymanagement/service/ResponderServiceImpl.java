package com.igate.surveymanagement.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.igate.surveymanagement.bean.QuestionBean;
import com.igate.surveymanagement.bean.SurveyBean;
import com.igate.surveymanagement.dao.IResponderDAO;


@Service
public class ResponderServiceImpl implements IResponderService {

	@Autowired
	IResponderDAO dao;

	@Override
	public List<SurveyBean> getSurveyList(String responderId) {
		// TODO Auto-generated method stub
		return dao.getSurveyList(responderId);
	}

	/*@Override
	public List<QuestionBean> getSurveyQuestions(String surveyId) {
		// TODO Auto-generated method stub
		return dao.getSurveyQuestions(surveyId);
	}*/

	@Override
	public List<QuestionBean> getSurveyDetails(String surveyId) {
		// TODO Auto-generated method stub
		return dao.getSurveyDetails(surveyId);
	}

	@Override
	public int respondSurvey(String surveyId,String userId,List<QuestionBean> quesList) {
		// TODO Auto-generated method stub
		return dao.respondSurvey(surveyId,userId,quesList);
	}


}
